<?php

$default_options = array();

$default_options['arprice_templates'] = '';
$default_options['id'] = 'arprice_default_id';
$default_options['class'] = '';
$default_options['style'] = '';
$default_options['heading'] = '';

return $default_options;