<div class="arp-select-table">
  <?php echo $settings->select_field; ?>
</div>