<?php

$data_value = '[ARPrice id=' .$atts['arprice_dropdown'].']';
echo "<h2>".$atts['arprice_title']."</h2>";
echo do_shortcode($data_value);